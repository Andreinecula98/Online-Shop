-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 31, 2020 at 04:06 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ose_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branduri`
--

CREATE TABLE `branduri` (
  `brand_id` int(100) NOT NULL,
  `brand_title` varchar(250) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `branduri`
--

INSERT INTO `branduri` (`brand_id`, `brand_title`) VALUES
(1, 'Samsung'),
(2, 'LG'),
(3, 'DELL'),
(4, 'Sony'),
(5, 'Asus'),
(6, 'Lenovo'),
(7, 'Apple'),
(8, 'Genesis');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `produs_id` int(11) NOT NULL,
  `produs_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ip_adress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `produs_id`, `produs_title`, `ip_adress`, `quantity`) VALUES
(31, 9, 'Telefon Samsung S9+', '::1', 1),
(32, 10, 'Monitor DELL', '::1', 1);

-- --------------------------------------------------------

--
-- Table structure for table `categori`
--

CREATE TABLE `categori` (
  `cat_id` int(100) NOT NULL,
  `cat_title` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `visible` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categori`
--

INSERT INTO `categori` (`cat_id`, `cat_title`, `visible`) VALUES
(8, 'PC', 1),
(9, 'Laptop', 1),
(10, 'Telefoane Mobile', 1),
(11, 'Televizoare', 1),
(12, 'Monitoare', 1);

-- --------------------------------------------------------

--
-- Table structure for table `conturi`
--

CREATE TABLE `conturi` (
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nume` text COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parola` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tara` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `oras` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `contact` text COLLATE utf8_unicode_ci NOT NULL,
  `adresa` text COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rol` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Guest'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `conturi`
--

INSERT INTO `conturi` (`user_id`, `ip_address`, `nume`, `email`, `parola`, `tara`, `oras`, `contact`, `adresa`, `image`, `rol`) VALUES
(7, '::1', 'admin', 'admin1@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'Armenia', '12', '123', '12323', 'dell.jpg', 'admin'),
(8, '::1', 'Andrei Necula', 'user@user.com', 'ee11cbb19052e40b07aac0ca060c23ee', 'Armenia', 'oras', '123', 'adresa', '111854725X[1].jpg', 'Guest'),
(9, '::1', 'Gogu', 'altuser@user.com', 'ee11cbb19052e40b07aac0ca060c23ee', 'Iran', 'oras', '07234556765', 'adresa', 'WIN_20190323_23_19_15_Pro.jpg', 'Guest');

-- --------------------------------------------------------

--
-- Table structure for table `produse`
--

CREATE TABLE `produse` (
  `produs_id` int(100) NOT NULL,
  `produs_cat` int(100) NOT NULL,
  `produs_brand` int(100) NOT NULL,
  `produs_title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `produs_pret` int(100) NOT NULL,
  `produs_desc` text COLLATE utf8_unicode_ci NOT NULL,
  `produs_img` text COLLATE utf8_unicode_ci NOT NULL,
  `produs_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `views` int(11) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `date` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `produse`
--

INSERT INTO `produse` (`produs_id`, `produs_cat`, `produs_brand`, `produs_title`, `produs_pret`, `produs_desc`, `produs_img`, `produs_key`, `views`, `visible`, `date`) VALUES
(8, 9, 6, 'Laptop Lenovo', 1500, 'Un laptop bun , chiar bun\r\n', 'laptop.jpg', 'laptop', 0, 0, ''),
(9, 10, 1, 'Telefon Samsung S9+', 3000, 'Un telefon bun, pre bun', 'S9+.jpg', 's9+', 0, 0, ''),
(10, 12, 3, 'Monitor DELL', 605, 'Un monitor de nota 10, va oferim o calitate superioara', 'dell.jpg', 'monitor', 0, 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branduri`
--
ALTER TABLE `branduri`
  ADD PRIMARY KEY (`brand_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categori`
--
ALTER TABLE `categori`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `conturi`
--
ALTER TABLE `conturi`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `produse`
--
ALTER TABLE `produse`
  ADD PRIMARY KEY (`produs_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branduri`
--
ALTER TABLE `branduri`
  MODIFY `brand_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `categori`
--
ALTER TABLE `categori`
  MODIFY `cat_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `conturi`
--
ALTER TABLE `conturi`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `produse`
--
ALTER TABLE `produse`
  MODIFY `produs_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
